// Update Date and Time
function updateDateTime() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    document.getElementById('dateTime').textContent = now.toLocaleDateString('en-US', options);
}

// Call on load and update every minute
updateDateTime();
setInterval(updateDateTime, 60000);

// To-Do List Functionality
const todoInput = document.getElementById('todoInput');
const addTodoBtn = document.getElementById('addTodoBtn');
const todoList = document.getElementById('todoList');

addTodoBtn.addEventListener('click', addTodo);
todoInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTodo();
});

function addTodo() {
    const task = todoInput.value.trim();
    if (task === '') return;

    const li = document.createElement('li');
    li.innerHTML = `<input type="checkbox"> ${task}`;
    todoList.appendChild(li);
    todoInput.value = '';
}

// Shopping List Functionality
const shoppingInput = document.getElementById('shoppingInput');
const addShoppingBtn = document.getElementById('addShoppingBtn');
const shoppingList = document.getElementById('shoppingList');

addShoppingBtn.addEventListener('click', addShopping);
shoppingInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addShopping();
});

function addShopping() {
    const item = shoppingInput.value.trim();
    if (item === '') return;

    const li = document.createElement('li');
    li.innerHTML = `<input type="checkbox"> ${item}`;
    shoppingList.appendChild(li);
    shoppingInput.value = '';
}

// Notes Functionality
const notesInput = document.getElementById('notesInput');
const saveNoteBtn = document.getElementById('saveNoteBtn');
const notesDisplay = document.getElementById('notesDisplay');

saveNoteBtn.addEventListener('click', saveNote);
notesInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && e.ctrlKey) saveNote();
});

function saveNote() {
    const noteText = notesInput.value.trim();
    if (noteText === '') return;

    const noteDiv = document.createElement('p');
    noteDiv.className = 'note';
    noteDiv.textContent = noteText;
    notesDisplay.appendChild(noteDiv);
    notesInput.value = '';
}

// Animation on load
window.addEventListener('load', () => {
    const widgets = document.querySelectorAll('.widget');
    widgets.forEach((widget, index) => {
        widget.style.opacity = '0';
        widget.style.transform = 'translateY(20px)';
        setTimeout(() => {
            widget.style.transition = 'all 0.5s ease';
            widget.style.opacity = '1';
            widget.style.transform = 'translateY(0)';
        }, index * 100);
    });
});